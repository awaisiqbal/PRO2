var searchData=
[
  ['ejemplo_20de_20dise_c3_b1o_20modular_3a_20_20gesti_c3_b3n_20de_20una_20lavadora_2e',['Ejemplo de diseño modular:  Gestión de una lavadora.',['../index.html',1,'']]]
];
