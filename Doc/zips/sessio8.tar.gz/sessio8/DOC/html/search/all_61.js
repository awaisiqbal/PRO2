var searchData=
[
  ['anadir_5fprenda',['anadir_prenda',['../class_cubeta.html#a431873df8f99cebe56b4787a5271e395',1,'Cubeta::anadir_prenda()'],['../class_lavadora.html#a7e465e1f11ba5ba3cffcee1ce9507e79',1,'Lavadora::anadir_prenda()']]]
];
